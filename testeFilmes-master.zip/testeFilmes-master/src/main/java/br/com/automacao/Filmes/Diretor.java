package br.com.automacao.Filmes;

public class Diretor {
	public String nome;
	public String dataNascimento;
}
