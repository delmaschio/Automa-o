package br.com.automacao.Filmes;

public class Filme {
	public String nome;
	public String anoLancamento;
}
